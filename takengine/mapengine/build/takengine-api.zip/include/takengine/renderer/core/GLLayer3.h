#pragma once

#include "renderer/core/GLLayer2.h"

namespace TAK
{
    namespace Engine
    {
        namespace Renderer
        {
            namespace Core
            {
                class GLLayer3 : public virtual TAK::Engine::Renderer::Core::GLLayer2
                {

                };
            }
        }
    }
}