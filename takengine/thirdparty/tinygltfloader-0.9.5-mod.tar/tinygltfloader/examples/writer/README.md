# Simple glTF writer in C++.

Read glTF with tinygltfloader, and write it to glTF JSON.

## TODO

* [ ] Asset export option(embed, external file)
* [ ] Textures
* [ ] Materials
* [ ] etc.

