This is a set of Delphi units for using the Assimp C DLL.  This was created for use with Delphi 7, but should be usable as-is or with minimal modifications with later Delphi versions.

This set of headers is enough to load and display a model with external textures.  Since I'm not familiar with animated models and some of the other functionality of the assimp library, I did not convert the headers for those features. 

See http://sourceforge.net/tracker/?func=detail&aid=3212646&group_id=226462&atid=1067634 for the original patch

