/*
 * $Revision$
 * $Date$
 */
package jassimp;


/**
 * Configuration interface for assimp importer.<p>
 * 
 * This class is work-in-progress
 */
public class AiConfig {

}
