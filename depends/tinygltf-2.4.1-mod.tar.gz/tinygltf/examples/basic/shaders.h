#pragma once

#include <GLES2/gl2.h>

class Shaders
{
public:
	GLuint pid;
	Shaders();
	~Shaders();
};

