# Simple serialization API sample.
