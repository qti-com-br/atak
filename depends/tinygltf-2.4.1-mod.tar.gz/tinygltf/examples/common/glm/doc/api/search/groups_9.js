var searchData=
[
  ['vector_20relational_20functions',['Vector Relational Functions',['../a00152.html',1,'']]]
];
