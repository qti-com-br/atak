var searchData=
[
  ['template_20types',['Template types',['../a00158.html',1,'']]],
  ['types',['Types',['../a00156.html',1,'']]]
];
