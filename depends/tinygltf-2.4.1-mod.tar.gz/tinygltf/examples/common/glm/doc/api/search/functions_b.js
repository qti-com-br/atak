var searchData=
[
  ['next_5ffloat',['next_float',['../a00179.html#gae516ae554faa6117660828240e8bdaf0',1,'glm::next_float(genType const &amp;x)'],['../a00179.html#gad107ec3d9697ef82032a33338a73ebdd',1,'glm::next_float(genType const &amp;x, uint const &amp;Distance)']]],
  ['nlz',['nlz',['../a00199.html#ga78dff8bdb361bf0061194c93e003d189',1,'glm']]],
  ['normalize',['normalize',['../a00147.html#gada9451ec170a36fe53552812b9c03a68',1,'glm::normalize(vecType&lt; T, P &gt; const &amp;x)'],['../a00172.html#ga35b6bcb22ac6d1e4a85440f5b69bdf86',1,'glm::normalize(tquat&lt; T, P &gt; const &amp;q)'],['../a00189.html#ga495818aa48c23e9e730f87a3c337d1d5',1,'glm::normalize(tdualquat&lt; T, P &gt; const &amp;q)']]],
  ['normalizedot',['normalizeDot',['../a00213.html#gaffbc2f2cb15838de8886a68048f9004d',1,'glm']]],
  ['not_5f',['not_',['../a00152.html#ga4329ecbc2ef012c9ec704bd09da1f177',1,'glm']]],
  ['notequal',['notEqual',['../a00152.html#ga5aca2b745e5eb0096716bbc394846309',1,'glm::notEqual(vecType&lt; T, P &gt; const &amp;x, vecType&lt; T, P &gt; const &amp;y)'],['../a00172.html#ga484c4633f7c05d8e29ee8b452350f539',1,'glm::notEqual(tquat&lt; T, P &gt; const &amp;x, tquat&lt; T, P &gt; const &amp;y)']]]
];
