var searchData=
[
  ['matrix_20functions',['Matrix functions',['../a00149.html',1,'']]]
];
