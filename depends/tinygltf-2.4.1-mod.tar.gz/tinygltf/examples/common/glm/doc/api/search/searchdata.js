var indexSectionsWithContent =
{
  0: "_abcdefghilmnopqrstuvwyz",
  1: "_abcdefghilmnoprstuvw",
  2: "abcdefghilmnopqrstuvwyz",
  3: "abdfhilmqsuvw",
  4: "acefgimptv",
  5: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "groups",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Typedefs",
  4: "Modules",
  5: "Pages"
};

