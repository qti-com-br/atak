var searchData=
[
  ['precision_20types',['Precision types',['../a00157.html',1,'']]]
];
