var searchData=
[
  ['exponential_20functions',['Exponential functions',['../a00146.html',1,'']]]
];
