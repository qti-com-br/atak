var searchData=
[
  ['optimum_5fpow_2ehpp',['optimum_pow.hpp',['../a00079.html',1,'']]],
  ['orthonormalize_2ehpp',['orthonormalize.hpp',['../a00080.html',1,'']]]
];
